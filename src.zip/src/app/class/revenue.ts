export class Revenue {
   
    constructor(
       public product_id: string,
       public orderID: number,
       public userID: string,
        
        public productCatagory: string,
       public productPrice: number
    ){};
    
}
