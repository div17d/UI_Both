import { Revenue } from './revenue';

describe('Revenue', () => {
  it('should create an instance', () => {
    expect(new Revenue()).toBeTruthy();
  });
});
