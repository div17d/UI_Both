export class Growth {
     
    constructor(
        public month: number,
        public year: number,
        public revenue: number,
        public change: number,
        public percentageGrowth: number,
        public colour: string 
       
     ){};
     
}
