import { Growth } from './growth';

describe('Growth', () => {
  it('should create an instance', () => {
    expect(new Growth()).toBeTruthy();
  });
});
