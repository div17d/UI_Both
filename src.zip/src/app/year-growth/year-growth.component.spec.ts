import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YearGrowthComponent } from './year-growth.component';

describe('ShowGrowthComponent', () => {
  let component: YearGrowthComponent;
  let fixture: ComponentFixture<YearGrowthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YearGrowthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YearGrowthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
