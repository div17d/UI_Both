import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AdminReportService } from "../service/admin-report.service";
import { Growth } from "../class/growth"

@Component({
  selector: 'app-show-growth',
  templateUrl: './year-growth.component.html',
  styleUrls: ['./year-growth.component.css']
})
export class YearGrowthComponent implements OnInit {
  year: number;
  month: number;
  growths: Growth[];

  constructor(private route: ActivatedRoute,private router: Router,
    private adminReportService: AdminReportService) { 
      this.year= this.route.snapshot.params['year'];
     // this.month= this.route.snapshot.params['month'];
  
      console.log(this.year);

     // this.revenues = adminReportService.getRevenue(this.productID);
     this.growths = adminReportService.showGrowthYearly(this.year);
    }

  ngOnInit(): void {
  }

  back(){
    this.router.navigate(['growthReport']);
  }

}
