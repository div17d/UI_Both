
import { Component, OnInit, Input } from '@angular/core';
import { ProductListComponent } from '../product-list/product-list.component';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from "rxjs";
import { AdminReportService } from "../service/admin-report.service";
import { Revenue } from "./../class/revenue";


@Component({
  selector: 'app-revenue-report',
  templateUrl: './revenue-report.component.html',
  styleUrls: ['./revenue-report.component.css']
})
export class RevenueReportComponent implements OnInit {
 productID: string;
 currentDate = new Date();
 // revenues= new Array();
  revenues: Revenue[];


  //constructor() { }
 // @Input() revevnue: Revenue;

  constructor(private route: ActivatedRoute,private router: Router,
    private adminReportService: AdminReportService) {
      this.productID= this.route.snapshot.paramMap.get('product_id');
  
      console.log(this.productID);

      this.revenues = adminReportService.getRevenue(this.productID);
     
      
     }
   

  ngOnInit() {
   

  
  

}
list(){
  this.router.navigate(['view']);
}
}
