import { TestBed } from '@angular/core/testing';

import { ShelfReportService } from './shelf-report.service';

describe('ShelfReportService', () => {
  let service: ShelfReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ShelfReportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
