import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Revenue} from '../class/revenue';
import { Growth } from '../class/growth'

@Injectable({
  providedIn: 'root'
})
export class AdminReportService {

  private baseUrl = 'http://localhost:9090/api';
  resultRevenue: Revenue[];
  resultGrowth: Growth[];

  constructor(private http: HttpClient) { }

  getRevenue(productID: String): Revenue[] {
   this.resultRevenue = [];
     this.http.get<Revenue[]>(`${this.baseUrl}/viewRevenue/${productID}`).subscribe((resultRevenues)=>
     {console.log(resultRevenues);
       Object.keys(resultRevenues).map(key => {
         this.resultRevenue.push(resultRevenues[key]);
         console.log(this.resultRevenue);
       });
     });
     return this.resultRevenue;
  }

  getProductList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/view`);
  }

  getSaleYearList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/saleYear`);
  }

  showGrowthYearly(year: number): Growth[]{
    this.resultGrowth = [];
    this.http.get<Growth[]>(`${this.baseUrl}/viewGrowth/year/${year}`).subscribe((resultGrowths)=>
    {
      Object.keys(resultGrowths).map(key => {
        this.resultGrowth.push(resultGrowths[key]);
        console.log(this.resultRevenue);
      });
    });
    return this.resultGrowth;
  }

  showGrowthMonthly(year: number,month: number): Growth[]{
    this.resultGrowth = [];
    this.http.get<Growth[]>(`${this.baseUrl}/viewGrowth/month/${month}/year/${year}`).subscribe((resultGrowths)=>
    {
      Object.keys(resultGrowths).map(key => {
        this.resultGrowth.push(resultGrowths[key]);
        console.log(this.resultRevenue);
      });
    });
    return this.resultGrowth;
  }

}

