import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})

export class ShelfReportService {
 

  private baseUrl = 'http://localhost:9092/api';

  constructor(private http: HttpClient) { }

  getRetailerList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/viewRetailer`);
  }

  getSaleYearList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/saleYear`);
  }

  getYearShelf(retailerID: String, year: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/viewYearlyReport/${retailerID}/year/${year}`);
  }

  getMonthShelf(retailerID: String, month: number, year: number,): Observable<any> {
    return this.http.get(`${this.baseUrl}/viewMonthlyReport/${retailerID}/${month}/year/${year}`);
  }

  getQuarterShelf(retailerID: String, quarter: String, year: number,): Observable<any> {
    return this.http.get(`${this.baseUrl}/viewQuarterlyReport/${retailerID}/quarter/${quarter}/year/${year}`);
  }

}
