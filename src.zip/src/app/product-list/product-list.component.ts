import { AdminReportService } from "../service/admin-report.service";
import { Component, OnInit } from "@angular/core";
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  orders= new Array(String);
  

  constructor(private revenueService: AdminReportService,
    private router: Router) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.revenueService.getProductList().subscribe(data => {
     // console.log(data)
      this.orders = data;
     });
  }

  getRevenue(productID: string){
    this.router.navigate(['viewRevenue', productID]);
  }

}
  