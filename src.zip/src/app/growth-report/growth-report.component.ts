import { Component, OnInit } from '@angular/core';
import { AdminReportService } from "../service/admin-report.service";
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-growth-report',
  templateUrl: './growth-report.component.html',
  styleUrls: ['./growth-report.component.css']
})
export class GrowthReportComponent implements OnInit {

  growthType = ["Yearly", "Monthly"];
  monthSelection = [1,2,3,4,5,6,7,8,9,10,11,12];
  saleYear= new Array(Number);
  //yearSelection= new Array(Number);
  selectedGrowth: String;
  year: number;
  month: number;
  currentYear= new Date();
  onChange(selectedGrowth){
    this.selectedGrowth=selectedGrowth;
    console.log(this.selectedGrowth);
  };
  startYear =Math.min.apply(this.saleYear); 
  endYear =Math.max.apply(this.saleYear); 

  

  constructor(private revenueService: AdminReportService,
    private router: Router) {

     }
    //selectedGrowth: String;

  ngOnInit(){
    
   this.onChange(this.selectedGrowth);
    this.revenueService.getSaleYearList().subscribe(data => {
      // console.log(data)
    console.log(this.selectedGrowth);
       this.saleYear = data;
      });
      

  }

 
}
