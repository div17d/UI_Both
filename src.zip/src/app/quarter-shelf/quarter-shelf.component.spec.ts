import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuarterShelfComponent } from './quarter-shelf.component';

describe('QuarterShelfComponent', () => {
  let component: QuarterShelfComponent;
  let fixture: ComponentFixture<QuarterShelfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuarterShelfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuarterShelfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
