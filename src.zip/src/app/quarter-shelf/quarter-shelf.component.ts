import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ShelfReportService } from "../service/shelf-report.service";

@Component({
  selector: 'app-quarter-shelf',
  templateUrl: './quarter-shelf.component.html',
  styleUrls: ['./quarter-shelf.component.css']
})
export class QuarterShelfComponent implements OnInit {
  year: number;
  retailerID: String;
  quarter: String;
  shelfReport: Map<String, String>;

  constructor(private route: ActivatedRoute,private router: Router,
    private shelfReportService: ShelfReportService) { 
      this.year= this.route.snapshot.params['year'];
      this.quarter= this.route.snapshot.params['quarter'];
      this.retailerID= this.route.snapshot.params['retailerID'];
    }

  ngOnInit(){
    this.shelfReportService.getQuarterShelf(this.retailerID, this.quarter, this.year).subscribe(data => {
      this.shelfReport = data;
      console.log(data);
     });
  }

}
