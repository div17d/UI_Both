import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MonthShelfComponent } from './month-shelf.component';

describe('MonthShelfComponent', () => {
  let component: MonthShelfComponent;
  let fixture: ComponentFixture<MonthShelfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MonthShelfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MonthShelfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
