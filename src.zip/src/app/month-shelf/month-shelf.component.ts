import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ShelfReportService } from "../service/shelf-report.service";

@Component({
  selector: 'app-month-shelf',
  templateUrl: './month-shelf.component.html',
  styleUrls: ['./month-shelf.component.css']
})
export class MonthShelfComponent implements OnInit {
  year: number;
  retailerID: String;
  month: number;
  shelfReport: Map<String, String>;

  constructor(private route: ActivatedRoute,private router: Router,
    private shelfReportService: ShelfReportService) { 
      this.year= this.route.snapshot.params['year'];
      this.month= this.route.snapshot.params['month'];
      this.retailerID= this.route.snapshot.params['retailerID'];
    }

  ngOnInit(){
    this.shelfReportService.getMonthShelf(this.retailerID, this.year, this.month).subscribe(data => {
      this.shelfReport = data;
      console.log(data);
     });
  }

}
