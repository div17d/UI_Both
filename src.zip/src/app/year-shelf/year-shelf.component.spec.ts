import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YearShelfComponent } from './year-shelf.component';

describe('YearShelfComponent', () => {
  let component: YearShelfComponent;
  let fixture: ComponentFixture<YearShelfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YearShelfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YearShelfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
