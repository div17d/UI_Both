import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ShelfReportService } from "../service/shelf-report.service";

@Component({
  selector: 'app-year-shelf',
  templateUrl: './year-shelf.component.html',
  styleUrls: ['./year-shelf.component.css']
})
export class YearShelfComponent implements OnInit {

  year: number;
  retailerID: String;
  shelfReport: Map<String, String>;

  constructor(private route: ActivatedRoute,private router: Router,
    private shelfReportService: ShelfReportService) {
      this.year= this.route.snapshot.params['year'];
      this.retailerID= this.route.snapshot.params['retailerID'];
     }

  ngOnInit() {
    this.shelfReportService.getYearShelf(this.retailerID, this.year).subscribe(data => {
      this.shelfReport = data;
      console.log(data);
     });

    
  }

}
