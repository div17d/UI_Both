import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RevenueReportComponent } from './revenue-report/revenue-report.component';
import { ProductListComponent } from './product-list/product-list.component';
import { AdminReportService } from './service/admin-report.service';
import { AdminComponent } from './admin/admin.component';
import { GrowthReportComponent } from './growth-report/growth-report.component';
import { FormsModule } from '@angular/forms';
import { YearGrowthComponent } from './year-growth/year-growth.component';
import { MonthGrowthComponent } from './month-growth/month-growth.component';
import { RetailerListComponent } from './retailer-list/retailer-list.component';
import { YearShelfComponent } from './year-shelf/year-shelf.component';
import { MonthShelfComponent } from './month-shelf/month-shelf.component';
import { QuarterShelfComponent } from './quarter-shelf/quarter-shelf.component';

@NgModule({
  declarations: [
    AppComponent,
    RevenueReportComponent,
    ProductListComponent,
    AdminComponent,
    GrowthReportComponent,
    YearGrowthComponent,
    MonthGrowthComponent,
    RetailerListComponent,
    YearShelfComponent,
    MonthShelfComponent,
    QuarterShelfComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [AdminReportService],
  bootstrap: [AppComponent]
})
export class AppModule { }
