import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductListComponent } from './product-list/product-list.component';
import { RevenueReportComponent } from './revenue-report/revenue-report.component';
import { GrowthReportComponent } from './growth-report/growth-report.component';
import { YearGrowthComponent } from './year-growth/year-growth.component';
import { MonthGrowthComponent } from './month-growth/month-growth.component';
import { RetailerListComponent } from './retailer-list/retailer-list.component';
import { YearShelfComponent } from './year-shelf/year-shelf.component';
import { MonthShelfComponent } from './month-shelf/month-shelf.component';
import { QuarterShelfComponent } from './quarter-shelf/quarter-shelf.component'



const routes: Routes = [
  { path: '', redirectTo: '/', pathMatch: 'full' },
  { path: 'view', component: ProductListComponent },
  { path: 'viewRevenue/:product_id', component: RevenueReportComponent },
  { path: 'growthReport', component: GrowthReportComponent },
  { path : 'yearGrowth/:year', component: YearGrowthComponent},
  { path : 'monthGrowth/:year/:month', component: MonthGrowthComponent},
  { path : 'retailer', component: RetailerListComponent},
  { path : 'retailer/:retailerID/:year', component: YearShelfComponent},
  { path : 'retailer/:retailerID/:month/:year', component: MonthShelfComponent},
  { path : 'retailerId/:retailerID/:quarter/:year', component: QuarterShelfComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
