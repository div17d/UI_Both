import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MonthGrowthComponent } from './month-growth.component';

describe('MonthGrowthComponent', () => {
  let component: MonthGrowthComponent;
  let fixture: ComponentFixture<MonthGrowthComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MonthGrowthComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MonthGrowthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
