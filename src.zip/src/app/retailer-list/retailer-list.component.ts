import { Component, OnInit } from '@angular/core';
import { ShelfReportService } from "../service/shelf-report.service";
import { AdminReportService} from "../service/admin-report.service"
import { Router } from '@angular/router';

@Component({
  selector: 'app-retailer-list',
  templateUrl: './retailer-list.component.html',
  styleUrls: ['./retailer-list.component.css']
})
export class RetailerListComponent implements OnInit {
  growthType = ["Yearly", "Monthly", "Quarterly"];
  monthSelection = [1,2,3,4,5,6,7,8,9,10,11,12];
  quarterSelection = ["Q1","Q2","Q3","Q4"];
  selectedShelf: String;
  retailers = new Array(String);
  saleYear= new Array(Number);
  year: number;
  month: number;
  quarter: String;


  onChange(selectedShelf){
    this.selectedShelf=selectedShelf;
    console.log(this.selectedShelf);
  };

  constructor(private shelfService: ShelfReportService,private adminService: AdminReportService,
    private router: Router) { }

  ngOnInit(){
    this.reloadData();
    this.onChange(this.selectedShelf);
   this.shelfService.getSaleYearList().subscribe(data => {
       this.saleYear = data;
      });
      
  }

  reloadData() {
    this.shelfService.getRetailerList().subscribe(data => {
      console.log(data);
      this.retailers = data;
     });
  }


}
